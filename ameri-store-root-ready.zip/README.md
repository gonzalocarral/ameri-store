# Ameri Store

Este es un proyecto básico de Next.js para cargar productos desde un archivo CSV y permitir compras simuladas.
